import torch
from torch_geometric.nn import GCNConv
import torch.nn.functional as F
from torch_geometric.utils import train_test_split_edges
from data_processing import load_and_process_data
import pandas as pd

class GCN(torch.nn.Module):
    def __init__(self, input_dim, hidden_dim, num_classes):
        super().__init__()
        self.conv1 = GCNConv(input_dim, hidden_dim)
        self.conv2 = GCNConv(hidden_dim, num_classes)

    def forward(self, data):
        x, edge_index = data.x, data.edge_index
        x = self.conv1(x, edge_index)
        x = F.relu(x)
        x = self.conv2(x, edge_index)
        return x


def train_and_evaluate(filepath, save_path='fraud_address_detection_model_checkpoint/gcn_model.pt'):
    data, num_nodes = load_and_process_data(filepath)
    mask = data.y != -1
    train_mask = torch.rand(len(data.y)) < 0.8
    train_mask = train_mask & mask
    test_mask = ~train_mask & mask

    model = GCN(input_dim=1, hidden_dim=16, num_classes=2)
    optimizer = torch.optim.Adam(model.parameters(), lr=0.01)

    for epoch in range(50):
        model.train()
        optimizer.zero_grad()
        out = model(data)
        loss = F.cross_entropy(out[train_mask], data.y[train_mask])
        loss.backward()
        optimizer.step()
        print(f"Epoch {epoch}, Loss: {loss.item():.4f}")

    # Save model parameters
    torch.save(model.state_dict(), save_path)
    print(f"Model saved to {save_path}")

    model.eval()
    pred = out[test_mask].argmax(dim=1)

    # Map predictions back to original addresses
    node_ids = torch.where(test_mask)[0]
    address_mapping = data['address_mapping']  # Assuming you saved address mapping dict during data processing

    predicted_addresses = []
    for node_id, label in zip(node_ids, pred):
        address = address_mapping[node_id.item()]  # Get original address using node_id
        predicted_addresses.append((address, label.item()))

    # Display prediction results (addresses and predicted labels)
    for address, label in predicted_addresses:
        print(f"Address: {address}, Predicted Label: {label}")

    # Calculate accuracy
    acc = (pred == data.y[test_mask]).sum().item() / test_mask.sum().item()
    print(f'Test Accuracy: {acc:.4f}')


if __name__ == "__main__":
    filepath = 'Dataset.csv'
    train_and_evaluate(filepath)
