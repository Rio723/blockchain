import pandas as pd
import numpy as np
import networkx as nx
import matplotlib.pyplot as plt


def load_transaction_data(file_path):
    """
    Load Ethereum transaction data from CSV file.
    """
    df = pd.read_csv(file_path)
    return df[['from_address', 'to_address', 'value']]


def build_transaction_graph(df):
    """
    Build a fund flow graph from Ethereum transactions.
    """
    G = nx.DiGraph()

    for _, row in df.iterrows():
        from_node = row['from_address']
        to_node = row['to_address']
        value = row['value']

        if G.has_edge(from_node, to_node):
            G[from_node][to_node]['weight'] += value
        else:
            G.add_edge(from_node, to_node, weight=value)

    return G


def filter_isolated_nodes(G, min_degree=1):
    """
    Filter out nodes with degree below threshold to avoid isolated nodes.
    """
    degree_dict = dict(G.degree())
    non_isolated_nodes = [node for node, degree in degree_dict.items() if degree >= min_degree]
    return G.subgraph(non_isolated_nodes)


def simplify_node_labels(G):
    """
    Simplify node labels by showing only first few characters to reduce visual clutter.
    """
    label_mapping = {}
    for node in G.nodes():
        label_mapping[node] = node[:5]  # Display first 5 characters
    return label_mapping


def visualize_filtered_graph(G, df):
    """
    Visualize the filtered fund flow graph with adjusted edge colors.
    """
    # Get total transaction volume for each node (sum of all outgoing transactions)
    node_transaction_value = df.groupby('from_address')['value'].sum()

    # Select top 100 nodes by transaction volume
    top_nodes = node_transaction_value.nlargest(500).index
    subgraph = G.subgraph(top_nodes)

    # Filter nodes with degree > 1
    filtered_subgraph = filter_isolated_nodes(subgraph, min_degree=2)

    # Get edge weights and apply logarithmic scaling
    raw_weights = [filtered_subgraph[u][v]['weight'] for u, v in filtered_subgraph.edges()]
    log_weights = [np.log10(w + 1) for w in raw_weights]  # log10 scaling, +1 to prevent log(0)

    # Set up color mapping
    min_log_w = min(log_weights)
    max_log_w = max(log_weights)
    norm = plt.Normalize(min_log_w, max_log_w)
    cmap = plt.cm.Reds
    edge_colors = [cmap(norm(w)) for w in log_weights]

    # Set edge widths (optional)
    edge_widths = [0.25 * w for w in log_weights]

    # Calculate node positions
    pos = nx.spring_layout(filtered_subgraph, k=0.15, iterations=20)

    # Simplify node labels
    label_mapping = simplify_node_labels(filtered_subgraph)

    # Draw graph
    plt.figure(figsize=(12, 12))
    nx.draw_networkx_nodes(filtered_subgraph, pos, node_size=50, node_color='blue', alpha=0.6)
    nx.draw_networkx_edges(filtered_subgraph, pos, edge_color=edge_colors, width=edge_widths, alpha=0.7)
    nx.draw_networkx_labels(filtered_subgraph, pos, labels=label_mapping, font_size=10, font_color='black')

    plt.title("Ethereum Transaction Flow Graph (Top 100 Nodes with >1 Connections, Log-Scaled Colors)")
    plt.axis('off')
    plt.show()


if __name__ == "__main__":
    # Load transaction data
    df = load_transaction_data('Dataset.csv')

    # Build transaction graph
    G = build_transaction_graph(df)

    # Visualize graph
    visualize_filtered_graph(G, df)
